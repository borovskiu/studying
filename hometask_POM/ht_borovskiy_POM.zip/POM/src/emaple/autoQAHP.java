package emaple;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class autoQAHP {
	
	WebDriver driver;
	By findField = By.id("search-page-q");
	By filmName = By.xpath("//*[@id=\"film-list\"]/div[1]/div[2]/b");
	By actor = By.xpath("/html/body/div[3]/div/div[2]/ul[3]/li/a[1]");
	By actorsName = By.xpath("/html/body/div[3]/div/div[2]/h4");
	

public autoQAHP (WebDriver driver){
	this.driver = driver;
}

public void setTheFilm(String theFilm){
	driver.findElement(findField).sendKeys(theFilm);
	driver.findElement(findField).submit();
}

public void chooseTheFilm(){
	driver.findElement(filmName).click();
}

public void findActor(){
	driver.findElement(actor).click();
}

public String getTheName(){
	String name;
	name = driver.findElement(actorsName).getText();
	System.out.println("name is: "+name);
	return name;
}

}
