package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import emaple.autoQAHP;
 
public class testQAHP {
 
	WebDriver driver;
	autoQAHP objFinder;
	
	
	@BeforeTest
	public void setup(){
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://my-hit.org/search/");
	}
 
	
	@Test(priority=0)
	public void findTheFilmByName(){
		objFinder = new autoQAHP(driver);
		objFinder.setTheFilm("batman");
	}
	
	@Test(priority=1)
	public void ChooseTheFilm(){
		objFinder = new autoQAHP(driver);
		objFinder.chooseTheFilm();
	}
	
	@Test(priority=2)
	public void findTheActor(){
		objFinder = new autoQAHP(driver);
		objFinder.findActor();
	}
	
	@Test(priority=3)
	public void assertName(){
		objFinder = new autoQAHP(driver);
		String name = objFinder.getTheName();
		Assert.assertEquals("Henry Cavill", name);
	}
	
	@AfterTest
	public void close(){
		driver.quit();
	}
}