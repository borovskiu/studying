package lesson_1;
import java.util.*;

public class task_1 {

	/**
	 * 1. Написати програму для роботи з списком. 
	 * У першій половині списку замінити всі входження деякого елементу Е1
	 *  на  будь-який інший елемент Е2;
	 */
	public static void main(String[] args) {
		
	  ArrayList <Integer> smth = new ArrayList();
      smth.add(5);smth.add(-5); smth.add(0);
      smth.add(10);smth.add(3);smth.add(17);
      smth.add(200);smth.add(5);
      	
      System.out.println("Начальный результат: "+smth);
      	
      int hm = smth.size();
      hm = hm/2;
      	
      for(int y = 0;y<hm;y++)
      {
          if(smth.get(y)==5)
          {
              smth.set(y, 100000);
          }
         
      }
      System.out.println("Итоговый результат: "+smth);

	}

}
