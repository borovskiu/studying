package lesson_2;
import java.util.*;

public class task_2 {

	/**
	 * 2. Задано масив цілих чисел. Вивести масив в оберненому порядку,
	 *  а потім видалити з нього повторні входження кожного елемента.
	 */
	public static void main(String[] args) {
		int []arr =  {1, 2, 3, 3, 2, 4, 5, 6, 5, 7, 5, 8};
	    
		Set <Integer> io = new HashSet();
	    for (int u=0; u<arr.length; u++)
	    {
	        io.add(arr[u]);
	    }
	    List list = new ArrayList(io);
	    Collections.reverse(list);
	    System.out.println(list); 

	}

}
