package lesson_3;

public class task_3 {

	/**
	 * 3. Найменший елемент масиву замінити цілою частиною середнього арифметичного 
	 * всіх елементів. Якщо в масиві є декілька найменших елементів, 
	 * то замінити останній з них.
	 */
	public static void main(String[] args) {
		int [] smth={1,6,1,3,1,6};
        int sum = 0;
        for(int y = 0; y<smth.length; y++)
        {
            sum = sum + smth[y];
        }
        int min = sum;
        for (int i=0; i<smth.length; i++)
        {
            if(smth[i]<min)
            {
                min = smth[i];
            }
        }
        
        int []arr = new int[smth.length];
        for(int i = 0; i<smth.length;i++)
        {
            arr[smth.length-i-1]=smth[i];
           
        }
        Boolean Task=false;
        for(int i = 0; i<arr.length; i++)
        {
            if (arr[i]==min && Task==false)
            {
                arr[i]=(sum/arr.length);
                Task = true;
            }
            else{}
           
        }
       
        int []app = new int[arr.length];
        for (int i = 0; i<arr.length;i++)
        {
            app[i]=arr[arr.length-i-1];
            System.out.print(app[i]+", ");
        }

	}

}
